import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  http: HttpClient;
  fetch: boolean = false;
  dept: Employee[] = [];
  constructor(http: HttpClient) {
    this.http = http;
  }
  fetchData() {
    this.http.get('./assets/Employee.json')
      .subscribe(data => {
        if (!this.fetch) {
          this.convert(data);
          this.fetch = true;
        }
      })
  }
  convert(data: any) {
    for (let emp of data) {
      let e = new Employee(emp.id, emp.name);
      this.dept.push(e)
    }
  }
  getData(): Employee[] {
    return this.dept;
  }
  add(e:Employee)
  {
    this.dept.push(e);
  }
  Delete(eid:number)
  {
    let foundIndex=-1;
    for(let i=0;i<this.dept.length;i++)
    {
      let e=this.dept[i]
      if(e.id==eid)
      {
        foundIndex=i;
        break;
      }
    }
    this.dept.splice(foundIndex,1);
  }
  update(data:Employee)
  {
let eid=data.id;
for(let i=0;i<this.dept.length;i++)
{
  if(eid==this.dept[i].id)
  {
    this.dept[i].name=data.name;
    break;
  }
}
  }
}
export class Employee {
  id: number;
  name: string;
  constructor(id: number, name: string) {
    this.id = id;
    this.name = name;
  }
}