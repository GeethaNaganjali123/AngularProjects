import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms'
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { AppRoutingModule } from './app_routing.module';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { EmployeeService } from './employee.service';
import { AddEmployeeComponent } from './add-employee/add-employee.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeelistComponent,
    AddEmployeeComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
