import { Component, OnInit } from '@angular/core';
import { Employee, EmployeeService } from '../employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  createEmployee:Employee
  service:EmployeeService
  createdFlag:boolean=true;

  constructor(service:EmployeeService) 
  {
    this.service=service;
   }
addData(data:any)
{
  this.createEmployee=new Employee(data.eid,data.ename)
  this.service.add(this.createEmployee);
  this.createdFlag=true;
}
  ngOnInit() {
  }

}
