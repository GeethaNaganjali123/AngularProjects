import { Component, OnInit } from '@angular/core';
import { EmployeeService, Employee } from '../employee.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {

  service:EmployeeService;
  deptData:Employee[]=[];
  
  constructor(service:EmployeeService) 
  {
    this.service=service;
   }

   Delete(id:number){
    this.service.Delete(id);
    this.deptData = this.service.getData()
   }

   isUpdate:boolean=true;
   
   updateData()
   {
     this.isUpdate=!this.isUpdate;
   }

   update(data:any)
   {
this.service.update(data)
this.deptData=this.service.getData();
   }


  ngOnInit() {
  this.service.fetchData();
  this.deptData=this.service.getData();
  }

}
